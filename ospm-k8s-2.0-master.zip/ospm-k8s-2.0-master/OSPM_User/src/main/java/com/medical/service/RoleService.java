package com.medical.service;

import com.medical.model.Role;

public interface RoleService {
    Role findByName(String name);

   
}
