package com.paytm;

import org.junit.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class PaytmPaymentGatewayApplicationTests {

	@Test
	void contextLoads() {
	}

}
