package com.ospm.order.repository;

import com.ospm.order.entity.Order_Product;

import org.springframework.data.jpa.repository.JpaRepository;

public interface Order_ProductRepository extends JpaRepository<Order_Product, Integer>{

    
    
}
