package com.ospm.cart;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class OspmCartApplicationTests {

	@Test
	void contextLoads() {
	}

}
