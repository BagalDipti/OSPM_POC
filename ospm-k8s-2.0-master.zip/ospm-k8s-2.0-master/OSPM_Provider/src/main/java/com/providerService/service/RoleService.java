package com.providerService.service;

import com.providerService.model.Role;

public interface RoleService {
    Role findByName(String name);

   
}